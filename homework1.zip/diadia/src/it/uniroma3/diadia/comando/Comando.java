package it.uniroma3.diadia.comando;

public class Comando {

}
